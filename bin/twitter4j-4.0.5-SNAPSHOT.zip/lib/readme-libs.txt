Twittetr4J is a Twitter API binding library for the Java language licensed under Apache License 2.0.

Twitter4J includes software from JSON.org to parse JSON response from the Twitter API. You can see the license term at http://www.JSON.org/license.html

readme-libs.txt - this file
twitter4j-core.jar - REST and Search API support 
twitter4j-async.jar - Async API support : use with twitter4j-core
twitter4j-media-support.jar - media API support : use with twitter4j-core
twitter4j-stream.jar - Streaming API support : use with twitter4j-core
twitter4j-examples.jar - examples : use with twitter4j-core, twitter4j-async and twitter4j-stream
twitter4j-spdy.jar - SPDY / HTTP2.0 support : adds SPDY / HTTP2.0 support, boosts Twitter4J performance, reduce packets, save the earth
